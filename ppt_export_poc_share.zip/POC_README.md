# PPT Export POC

This POC exports analysis responses into PowerPoint using stored message/session history.

## What Is Included

- FastAPI backend endpoints for layout preview, slide preview, and PPT export.
- Integrated browser UI at `/layout-picker`.
- Heuristic bullet extraction instead of a Snowflake Cortex inference call.
- Support for old final-text responses and newer streamed event responses.
- Multiple chart/event slides from one message ID.
- Per-slide template layout selection when a PPT template is available.
- Fallback config mode when no template is available.
- Template palette extraction with black/white filtered out.
- Reusable `PPTXGenerator` class for future integrations.

## Main API Endpoints

- `GET /layout-picker` - browser UI.
- `GET /export/layouts` - returns template layouts, thumbnails, and palette colors.
- `POST /export/preview/{dcs_id}` - previews generated slide count from message IDs.
- `POST /export/ppt/{dcs_id}` - exports the final PPTX.

## Class Usage

```python
from app.services.ppt_service import PPTXGenerator

generator = PPTXGenerator(
    template_path="ppt template export/merkle_template.potx",
    config_path="app/config/chart_colors.json",
)

ppt_path = generator.generate(
    presentation_json=presentation_json,
    include_charts=True,
    ppt_config=None,
    selected_colors=None,
)
```

The existing `generate_pptx(...)` function is still available as a backward-compatible wrapper.

## Run Locally

```powershell
.\venv\Scripts\python.exe -m uvicorn app.main:app --reload
```

Open:

```text
http://127.0.0.1:8000/layout-picker
```

## Notes

- If `ppt template export/merkle_template.potx` exists, template layouts are used for design.
- If the template is missing, layout selection is skipped and fallback config is used.
- PowerPoint on Windows or LibreOffice on Linux can render layout thumbnails; otherwise schematic previews are used.
