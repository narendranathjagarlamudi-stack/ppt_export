from fastapi import (
    FastAPI,
    HTTPException,
    Depends,
)

from fastapi.responses import FileResponse, HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from pathlib import Path

from sqlalchemy.orm import Session

from pydantic import BaseModel

from typing import Any, Dict, List, Optional

from app.database.postgres_conn import (
    get_db
)

from app.services.history_service import (
    fetch_chat_contexts
)

from app.services.presentation_service import (
    generate_presentation_content
)

from app.services.ppt_service import (
    generate_pptx
)

from app.services.layout_service import (
    get_layouts as get_template_layouts
)


LAYOUT_PICKER_STATIC_DIR = (
    Path(__file__).resolve().parents[1]
    / "app"
    / "static"
    / "layout_picker"
)


app = FastAPI(
    title="PPT Export Service"
)

app.mount(
    "/layout-static",
    StaticFiles(directory=LAYOUT_PICKER_STATIC_DIR),
    name="layout-static"
)


@app.get("/health")
async def health():

    return {
        "message":
            "PPT Export Service Running"
    }


@app.get("/")
async def root():

    return RedirectResponse(
        url="/layout-picker"
    )


class PPTExportRequest(BaseModel):

    dih_ids: List[int]

    include_charts: bool = True

    ppt_config: Optional[Dict[str, Any]] = None

    chart_colors: Optional[Dict[str, Any]] = None

    slide_layouts: Optional[Dict[str, Any]] = None

    selected_colors: Optional[List[str]] = None


class PPTPreviewRequest(BaseModel):

    dih_ids: List[int]


@app.get("/layout-picker", response_class=HTMLResponse)
async def layout_picker():

    html = (
        LAYOUT_PICKER_STATIC_DIR
        / "index.html"
    ).read_text(
        encoding="utf-8"
    )

    return html.replace(
        "/static/",
        "/layout-static/"
    )


@app.get("/export/layouts")
async def export_layouts():

    return get_template_layouts()


async def _build_slides_from_history(
    db: Session,
    dcs_id: int,
    dih_ids: List[int],
    slide_layouts: Optional[Dict[str, Any]] = None,
):

    chat_contexts = fetch_chat_contexts(

        db=db,

        dcs_id=dcs_id,

        dih_ids=dih_ids
    )

    if not chat_contexts:

        raise HTTPException(
            status_code=404,
            detail="No chat history found"
        )

    slides = []
    slide_metadata = []
    slide_index = 0
    conn = None

    for ctx in chat_contexts:

        slide_json = (
            await generate_presentation_content(

                conn=conn,

                original_query=ctx.get(
                    "query",
                    ""
                ),

                original_response=ctx.get(
                    "response",
                    {}
                ),
            )
        )

        generated_slides = (
            slide_json
            if isinstance(slide_json, list)
            else [slide_json]
        )

        for generated_slide in generated_slides:

            if slide_layouts:

                selected_layout = None

                for layout_key in (
                    str(slide_index),
                    slide_index,
                    "default"
                ):

                    if layout_key in slide_layouts:
                        selected_layout = slide_layouts[layout_key]
                        break

                if selected_layout is not None:
                    generated_slide["layout"] = selected_layout

            slides.append(generated_slide)
            slide_metadata.append({
                "index": slide_index,
                "dih_id": ctx.get("dih_id"),
                "message_id": ctx.get("message_id"),
                "query": ctx.get("query", ""),
                "title": (
                    generated_slide
                    .get("slide", {})
                    .get("title", "Key Insights")
                ),
                "bullet_count": len(
                    generated_slide
                    .get("slide", {})
                    .get("bullets", [])
                ),
                "has_chart": bool(
                    generated_slide.get("chart_spec")
                ),
            })
            slide_index += 1

    return slides, slide_metadata


@app.post("/export/preview/{dcs_id}")
async def export_preview(

    dcs_id: int,

    req: PPTPreviewRequest,

    db: Session = Depends(get_db),
):

    slides, slide_metadata = await _build_slides_from_history(
        db=db,
        dcs_id=dcs_id,
        dih_ids=req.dih_ids
    )

    return {
        "slide_count": len(slides),
        "slides": slide_metadata
    }


@app.post("/export/ppt/{dcs_id}")
async def export_ppt(

    dcs_id: int,

    req: PPTExportRequest,

    db: Session = Depends(get_db),
):

    try:
        slides, _ = await _build_slides_from_history(
            db=db,
            dcs_id=dcs_id,
            dih_ids=req.dih_ids,
            slide_layouts=req.slide_layouts
        )

        # ============================================
        # FINAL JSON
        # ============================================

        presentation_json = {

            "presentation_title":
                "Analysis Summary",

            "slides":
                slides
        }

        # ============================================
        # GENERATE PPT
        # ============================================

        ppt_path = generate_pptx(

            presentation_json=presentation_json,

            include_charts=req.include_charts,

            ppt_config=(
                req.ppt_config
                or req.chart_colors
            ),

            selected_colors=req.selected_colors
        )

        return FileResponse(

            path=ppt_path,

            media_type=(
                "application/vnd.openxmlformats-"
                "officedocument.presentationml."
                "presentation"
            ),

            filename="analysis_export.pptx"
        )

    except HTTPException:

        raise

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )

