const layoutGrid = document.getElementById("layoutGrid");
const layoutsPanel = document.getElementById("layoutsPanel");
const layoutMenu = document.getElementById("layoutMenu");
const layoutDropdownBtn = document.getElementById("layoutDropdownBtn");
const selectedPreview = document.getElementById("selectedPreview");
const dropdownSelectedName = document.getElementById("dropdownSelectedName");
const dropdownSelectedMeta = document.getElementById("dropdownSelectedMeta");
const templatePath = document.getElementById("templatePath");
const previewMode = document.getElementById("previewMode");
const selectedCard = document.getElementById("selectedCard");
const selectedName = document.getElementById("selectedName");
const selectedMeta = document.getElementById("selectedMeta");
const exportBtn = document.getElementById("exportBtn");
const previewBtn = document.getElementById("previewBtn");
const applyLayoutToSlidesBtn = document.getElementById("applyLayoutToSlidesBtn");
const refreshBtn = document.getElementById("refreshBtn");
const statusText = document.getElementById("statusText");

const chartToggle = document.getElementById("chartToggle");
const paletteGrid = document.getElementById("paletteGrid");
const paletteMeta = document.getElementById("paletteMeta");
const defaultColorsBtn = document.getElementById("defaultColorsBtn");
const selectAllColorsBtn = document.getElementById("selectAllColorsBtn");
const clearColorsBtn = document.getElementById("clearColorsBtn");
const dcsIdInput = document.getElementById("dcsIdInput");
const dihIdsInput = document.getElementById("dihIdsInput");
const pptConfigInput = document.getElementById("pptConfigInput");
const fallbackModeNote = document.getElementById("fallbackModeNote");
const slidePreviewMeta = document.getElementById("slidePreviewMeta");
const slidePreviewList = document.getElementById("slidePreviewList");

const layoutsEndpoint = "/export/layouts";

let layouts = [];
let selectedLayout = null;
let palette = [];
let selectedColors = new Set();
let useTemplateDefaultColors = true;
let previewSlides = [];
let slideSelections = {};
let templateLayoutsAvailable = false;

function setStatus(message) {
  statusText.textContent = message || "";
}

function selectLayout(layout) {
  selectedLayout = layout;
  selectedName.textContent = `${layout.index}: ${layout.name}`;
  selectedMeta.textContent = layoutSummary(layout);
  dropdownSelectedName.textContent = `${layout.index}: ${layout.name}`;
  dropdownSelectedMeta.textContent = layoutSummary(layout);
  selectedPreview.src = layout.preview;
  previewBtn.disabled = false;
  exportBtn.disabled = !previewSlides.length;
  layoutMenu.hidden = true;

  document.querySelectorAll(".layout-card").forEach((card) => {
    card.classList.toggle(
      "selected",
      Number(card.dataset.index) === layout.index
    );
  });

  renderSlidePreviewList();
}

function renderLayoutCard(layout) {
  const card = document.createElement("button");
  card.type = "button";
  card.className = "layout-card";
  card.dataset.index = String(layout.index);

  const image = document.createElement("img");
  image.src = layout.preview;
  image.alt = `${layout.name} preview`;

  const title = document.createElement("strong");
  title.textContent = `${layout.index}: ${layout.name}`;

  const meta = document.createElement("span");
  meta.textContent = layoutSummary(layout);

  card.append(image, title, meta);
  card.addEventListener("click", () => selectLayout(layout));

  return card;
}

function defaultContentLayout() {
  return (
    layouts.find((layout) => layout.name === "Title & Body")
    || layouts.find((layout) => layout.name.includes("Title & Body"))
    || layouts.find((layout) => layout.name === "Custom Layout")
    || layouts.find((layout) => layout.name === "Blank")
    || layouts[0]
  );
}

function selectedColorList() {
  if (useTemplateDefaultColors) {
    return [];
  }

  return palette
    .map((color) => color.hex)
    .filter((color) => selectedColors.has(color));
}

function layoutByIndex(index) {
  return layouts.find((layout) => layout.index === Number(index));
}

function layoutSummary(layout) {
  if (!layout) {
    return "No layout selected";
  }

  const contentText = layout.has_content_placeholder
    ? "has content area"
    : "no content area";

  return `${layout.placeholder_count} placeholders, ${contentText}`;
}

function resetPreviewState() {
  previewSlides = [];
  slideSelections = {};
  slidePreviewMeta.textContent = "Preview slide count before export.";
  slidePreviewList.replaceChildren();
  applyLayoutToSlidesBtn.disabled = true;
  exportBtn.disabled = true;
}

function enterFallbackConfigMode(message) {
  layouts = [];
  palette = [];
  selectedColors = new Set();
  useTemplateDefaultColors = true;
  templateLayoutsAvailable = false;
  selectedLayout = null;

  selectedName.textContent = "Fallback config mode";
  selectedMeta.textContent = "No template layouts are available. Export will use fallback PPT config JSON.";
  dropdownSelectedName.textContent = "No template loaded";
  dropdownSelectedMeta.textContent = "Using fallback PPT config";
  selectedPreview.removeAttribute("src");
  templatePath.textContent = "Template not available";
  previewMode.textContent = message || "Fallback config mode.";
  layoutsPanel.hidden = true;
  selectedCard.hidden = true;
  layoutDropdownBtn.disabled = true;
  fallbackModeNote.hidden = false;
  layoutGrid.replaceChildren();
  layoutMenu.hidden = true;
  previewBtn.disabled = false;
  applyLayoutToSlidesBtn.hidden = true;
  renderPalette();
}

function renderPalette() {
  paletteGrid.replaceChildren();

  if (!palette.length) {
    paletteMeta.textContent = "No explicit RGB colors found.";
    return;
  }

  if (useTemplateDefaultColors) {
    paletteMeta.textContent = "Using template default chart colors.";
  } else {
    paletteMeta.textContent = `${selectedColors.size} of ${palette.length} selected`;
  }

  const swatches = palette.map((color) => {
    const swatch = document.createElement("button");
    swatch.type = "button";
    swatch.className = "swatch";
    swatch.style.backgroundColor = color.hex;
    swatch.title = `${color.hex} (${color.count} uses)`;
    swatch.classList.toggle(
      "selected",
      !useTemplateDefaultColors && selectedColors.has(color.hex)
    );

    swatch.addEventListener("click", () => {
      useTemplateDefaultColors = false;

      if (selectedColors.has(color.hex)) {
        selectedColors.delete(color.hex);
      } else {
        selectedColors.add(color.hex);
      }

      renderPalette();
    });

    return swatch;
  });

  paletteGrid.replaceChildren(...swatches);
}

async function loadLayouts() {
  setStatus("Loading layouts...");
  exportBtn.disabled = true;
  previewBtn.disabled = true;
  resetPreviewState();
  selectedLayout = null;
  templateLayoutsAvailable = false;
  layoutsPanel.hidden = false;
  selectedCard.hidden = false;
  layoutDropdownBtn.disabled = false;
  applyLayoutToSlidesBtn.hidden = false;
  fallbackModeNote.hidden = true;
  selectedName.textContent = "None";
  selectedMeta.textContent = "Pick a layout for the exported slides.";
  dropdownSelectedName.textContent = "Select a layout";
  dropdownSelectedMeta.textContent = "Open layout gallery";
  selectedPreview.removeAttribute("src");
  layoutMenu.hidden = true;
  layoutGrid.replaceChildren();

  const response = await fetch(layoutsEndpoint);

  if (!response.ok) {
    enterFallbackConfigMode(
      "Template layouts could not be loaded. You can still export with fallback PPT config JSON."
    );
    setStatus("Template layout load failed. Fallback config export is available.");
    return;
  }

  const payload = await response.json();
  layouts = payload.layouts || [];
  templateLayoutsAvailable = layouts.length > 0;
  palette = payload.palette || [];
  selectedColors = new Set(palette.map((color) => color.hex));
  useTemplateDefaultColors = true;
  templatePath.textContent = payload.template || "Template loaded";
  if (payload.preview_mode === "powerpoint") {
    previewMode.textContent = "Rendered previews via Microsoft PowerPoint.";
  } else if (payload.preview_mode === "libreoffice") {
    previewMode.textContent = `Rendered previews via ${payload.renderer}.`;
  } else {
    previewMode.textContent =
      payload.renderer_error
        ? `Schematic previews. ${payload.renderer_error}`
        : "Schematic previews. Install pywin32/Office on Windows or LibreOffice for rendered previews.";
  }

  layoutGrid.replaceChildren(...layouts.map(renderLayoutCard));
  renderPalette();

  if (layouts.length) {
    selectLayout(defaultContentLayout());
  }

  setStatus(`Loaded ${layouts.length} layouts.`);
}

function parseIds(value) {
  return value
    .split(",")
    .map((item) => item.trim())
    .filter((item) => item.length)
    .map((item) => Number(item))
    .filter((item) => Number.isInteger(item));
}

function parsePptConfig() {
  const rawConfig = pptConfigInput.value.trim();

  if (!rawConfig) {
    return null;
  }

  try {
    const parsed = JSON.parse(rawConfig);

    if (!parsed || Array.isArray(parsed) || typeof parsed !== "object") {
      throw new Error("Config must be a JSON object.");
    }

    return parsed;
  } catch (error) {
    throw new Error(`Fallback PPT config JSON is invalid: ${error.message}`);
  }
}

function renderSlidePreviewList() {
  slidePreviewList.replaceChildren();

  if (!previewSlides.length) {
    applyLayoutToSlidesBtn.disabled = true;
    exportBtn.disabled = true;
    return;
  }

  applyLayoutToSlidesBtn.disabled = !selectedLayout || !templateLayoutsAvailable;
  exportBtn.disabled = false;

  const rows = previewSlides.map((slide) => {
    const row = document.createElement("div");
    row.className = "slide-row";

    const details = document.createElement("div");
    details.className = "slide-row-details";

    const title = document.createElement("strong");
    title.textContent = `Slide ${slide.index + 1}: ${slide.title || "Key Insights"}`;

    const meta = document.createElement("span");
    const chartText = slide.has_chart ? "chart" : "no chart";
    meta.textContent = `DIH ${slide.dih_id || "-"} - ${slide.bullet_count} bullets - ${chartText}`;

    details.append(title, meta);

    let select = null;
    const key = String(slide.index);

    if (templateLayoutsAvailable) {
      select = document.createElement("select");
      select.className = "slide-layout-select";

      layouts.forEach((layout) => {
        const option = document.createElement("option");
        option.value = String(layout.index);
        option.textContent = `${layout.index}: ${layout.name}`;
        select.append(option);
      });

      if (!Object.prototype.hasOwnProperty.call(slideSelections, key)) {
        slideSelections[key] = selectedLayout
          ? selectedLayout.index
          : defaultContentLayout().index;
      }

      select.value = String(slideSelections[key]);
      select.addEventListener("change", () => {
        slideSelections[key] = Number(select.value);
        renderSlidePreviewList();
      });
    } else {
      select = document.createElement("p");
      select.className = "fallback-layout-note";
      select.textContent = "Fallback PPT config layout will be used.";
    }

    row.append(details, select);
    return row;
  });

  slidePreviewList.replaceChildren(...rows);
}

async function previewExport() {
  const dcsId = Number(dcsIdInput.value.trim());
  const dihIds = parseIds(dihIdsInput.value);

  if (!Number.isInteger(dcsId) || !dihIds.length) {
    setStatus("Enter a valid DCS ID and at least one message/DIH ID.");
    return false;
  }

  setStatus("Building slide preview...");
  previewBtn.disabled = true;
  exportBtn.disabled = true;

  try {
    const response = await fetch(`/export/preview/${dcsId}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        dih_ids: dihIds,
      }),
    });

    if (!response.ok) {
      throw new Error(await response.text());
    }

    const payload = await response.json();
    previewSlides = payload.slides || [];
    slideSelections = {};

    const defaultIndex = templateLayoutsAvailable
      ? (
        selectedLayout
          ? selectedLayout.index
          : defaultContentLayout().index
      )
      : null;

    previewSlides.forEach((slide) => {
      if (defaultIndex !== null) {
        slideSelections[String(slide.index)] = defaultIndex;
      }
    });

    slidePreviewMeta.textContent = `${payload.slide_count || previewSlides.length} slides will be generated.`;
    renderSlidePreviewList();
    setStatus("Preview ready. Choose a layout per slide, then export.");
    return true;
  } catch (error) {
    resetPreviewState();
    setStatus(`Preview failed: ${error.message}`);
    return false;
  } finally {
    previewBtn.disabled = templateLayoutsAvailable
      ? !selectedLayout
      : false;
  }
}

async function exportMessages() {
  if (templateLayoutsAvailable && !selectedLayout) {
    return;
  }

  const dcsId = Number(dcsIdInput.value.trim());
  const dihIds = parseIds(dihIdsInput.value);

  if (!Number.isInteger(dcsId) || !dihIds.length) {
    setStatus("Enter a valid DCS ID and at least one message/DIH ID.");
    return;
  }

  let pptConfig = null;

  try {
    pptConfig = parsePptConfig();
  } catch (error) {
    setStatus(error.message);
    return;
  }

  if (!previewSlides.length) {
    const previewOk = await previewExport();

    if (!previewOk) {
      return;
    }
  }

  const slideLayouts = {};

  if (templateLayoutsAvailable) {
    previewSlides.forEach((slide) => {
      const key = String(slide.index);
      slideLayouts[key] = Object.prototype.hasOwnProperty.call(slideSelections, key)
        ? slideSelections[key]
        : selectedLayout.index;
    });

    slideLayouts.default = selectedLayout.index;
  }

  const body = {
    dih_ids: dihIds,
    include_charts: chartToggle.checked,
    selected_colors: selectedColorList(),
  };

  if (templateLayoutsAvailable) {
    body.slide_layouts = slideLayouts;
  }

  if (pptConfig) {
    body.ppt_config = pptConfig;
  }

  setStatus("Exporting selected messages...");
  exportBtn.disabled = true;

  try {
    const response = await fetch(`/export/ppt/${dcsId}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    });

    if (!response.ok) {
      throw new Error(await response.text());
    }

    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "analysis_export.pptx";
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
    setStatus("Downloaded analysis_export.pptx.");
  } catch (error) {
    setStatus(`Export failed: ${error.message}`);
  } finally {
    exportBtn.disabled = !previewSlides.length;
  }
}

refreshBtn.addEventListener("click", () => {
  loadLayouts().catch((error) => setStatus(`Load failed: ${error.message}`));
});

defaultColorsBtn.addEventListener("click", () => {
  useTemplateDefaultColors = true;
  renderPalette();
});

selectAllColorsBtn.addEventListener("click", () => {
  useTemplateDefaultColors = false;
  selectedColors = new Set(palette.map((color) => color.hex));
  renderPalette();
});

clearColorsBtn.addEventListener("click", () => {
  useTemplateDefaultColors = false;
  selectedColors = new Set();
  renderPalette();
});

previewBtn.addEventListener("click", previewExport);

applyLayoutToSlidesBtn.addEventListener("click", () => {
  if (!templateLayoutsAvailable || !selectedLayout || !previewSlides.length) {
    return;
  }

  previewSlides.forEach((slide) => {
    slideSelections[String(slide.index)] = selectedLayout.index;
  });

  renderSlidePreviewList();
  setStatus("Selected layout applied to all previewed slides.");
});

dcsIdInput.addEventListener("input", resetPreviewState);
dihIdsInput.addEventListener("input", resetPreviewState);

layoutDropdownBtn.addEventListener("click", () => {
  if (!templateLayoutsAvailable) {
    return;
  }

  layoutMenu.hidden = !layoutMenu.hidden;
});

document.addEventListener("click", (event) => {
  const target = event.target;

  if (
    !layoutMenu.hidden &&
    !layoutMenu.contains(target) &&
    !layoutDropdownBtn.contains(target)
  ) {
    layoutMenu.hidden = true;
  }
});

exportBtn.addEventListener("click", exportMessages);

loadLayouts().catch((error) => setStatus(`Load failed: ${error.message}`));
